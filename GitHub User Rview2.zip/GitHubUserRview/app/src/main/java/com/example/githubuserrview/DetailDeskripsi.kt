package com.example.githubuserrview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
//import android.widget.TextView

class DetailDeskripsi : AppCompatActivity() {

    /*companion object {
        const val DETAIL_DATA = "detail_data"
    }*/

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_deskripsi)

        supportActionBar!!.title = "Back"
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        /*val t4DetailDeskripsi: TextView = findViewById(R.id.detail_deskripsi)

        val intent = intent.getParcelableExtra<Paket>(DETAIL_DATA) as Paket
        val skrip = "Id Github : ${intent.username}, \nNama : ${intent.surename}"
        t4DetailDeskripsi.text = skrip

         */
    }
}