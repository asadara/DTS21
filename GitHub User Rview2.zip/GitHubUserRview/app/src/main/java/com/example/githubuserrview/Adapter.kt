package com.example.githubuserrview

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

//dalam 1 class Adapter ini, bisa memiliki beberapa viewHolder
class Adapter1 (private val listPaket: ArrayList<Paket>) : RecyclerView.Adapter<Adapter1.Holder1>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder1 {
        val tampil1: View = LayoutInflater.from(parent.context).inflate(R.layout.layout1,parent,false)
        return Holder1(tampil1)
    }

    override fun onBindViewHolder(holder: Holder1, position: Int) {
        val (username, surename, photo) = listPaket[position]
        holder.t4foto.setImageResource(photo)
        holder.t4userId.text = username
        holder.t4nama.text = surename

        //fungsi OnClick pada kelas adapter :
        holder.itemView.setOnClickListener {
            val pindahkeDetail = Intent(holder.itemView.context, DetailDeskripsi::class.java)
            holder.itemView.context.startActivity(pindahkeDetail)
        }
    }

    //untuk menentukan ukuran data yg INGIN ditampilkan
    override fun getItemCount(): Int = listPaket.size

    class Holder1(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var t4foto: ImageView = itemView.findViewById(R.id.foto)
        var t4userId: TextView = itemView.findViewById(R.id.wadah1)
        var t4nama: TextView = itemView.findViewById(R.id.wadah2)
    }
}
