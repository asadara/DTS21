package com.example.githubuserrview

import android.annotation.SuppressLint
import android.content.res.Configuration
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class MainActivity : AppCompatActivity() {
    private lateinit var rvG: RecyclerView
    private val daftar = ArrayList<Paket>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(R.style.Theme_GitHubUserRview)
        setContentView(R.layout.activity_main)

        rvG = findViewById(R.id.rv)
        rvG.setHasFixedSize(true)

        daftar.addAll(daftarGh)
        tampilDaftar()

    }

    private val daftarGh: ArrayList<Paket>
        @SuppressLint("Recycle")
        get () {
            val dataId = resources.getStringArray(R.array.username)
            val dataNama = resources.getStringArray(R.array.surename)
            val dataFoto = resources.obtainTypedArray(R.array.avatar)

            val daftarG = ArrayList<Paket>()

            for (i in dataId.indices) {
                val gh = Paket(dataId[i], dataNama[i], dataFoto.getResourceId(i, -1))
                daftarG.add(gh)
            }
            return daftarG
        }

    private fun tampilDaftar() {
        if (applicationContext.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            rvG.layoutManager = GridLayoutManager(this, 2)
        } else {
            rvG.layoutManager = LinearLayoutManager(this)
        }
        val listPaketAdapter = Adapter1(daftar)
        rvG.adapter = listPaketAdapter

    }
}