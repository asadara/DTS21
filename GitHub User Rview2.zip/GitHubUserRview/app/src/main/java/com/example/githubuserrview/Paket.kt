package com.example.githubuserrview

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Paket(

    var username: String,
    var surename: String,
    var photo: Int

) : Parcelable

